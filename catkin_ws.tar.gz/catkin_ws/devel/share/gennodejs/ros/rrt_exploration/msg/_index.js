
"use strict";

let PointArray = require('./PointArray.js');

module.exports = {
  PointArray: PointArray,
};
